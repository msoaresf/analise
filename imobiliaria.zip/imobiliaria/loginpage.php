
<html>
    <head>
        <meta charset="UTF-8">
        <title>Marca da terra</title>
        <meta charset="utf-8">

        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
        <link href="css/bootstrap.min.css" rel="stylesheet"/>
        <script src="../js/jquery.min.js" type="text/javascript"></script>
        <script src="js/bootstrap.bundle.min.js"></script>
        <script src="js/jquery-3.7.0.min.js"></script>
        <link href="css/jquery.dataTables.min.css" rel="stylesheet" />
        <script src="js/jquery.dataTables.min.js" ></script>
        <style>
            body{
                width: 100%;
                height: 100%;
                display: block;
                background-image: linear-gradient( to bottom, rgba(29, 91, 62) 15%, white );
                background-position: center center;
                background-repeat: no-repeat;
                background-size: cover;
            }
            .login{
                background-color: rgba(255, 255, 255);
                border-radius: 10px;
                box-sizing: border-box;
                display: block;
                flex-direction: column;
                margin: 10%;
                min-height: 90%;
                padding: 0px 20px 40px;
                width: 100%;

            }
        </style>

    </head>
    <body>
        <br> <br> <br> <br> <br>
        <div class="row"> 
            <div class="col-md-4"> </div>
            <div class="col-md-4">
                <div class="login">   <br>
                    <h1 style="text-align: center;">ENTRAR</h1>
                    <hr> <br> <br>
                    <form method="post" action=".php">
                        <label style="" for="email" class="form-label">Email:</label>
                        <br>
                        <input type="password" class="form-control" id="Email"  placeholder="Senha" name="senha" required="">

                        <br> <br>
                        <label style="" for="email" class="form-label">Senha:</label>
                        <br>
                        <input type="password" class="form-control" id="senha"  placeholder="Senha" name="senha" required="">
                        <br>
                        <div class="mb- mt-3">
                            <div class="d-grid">
                                <button type="submit"class="btn btn-success">Entrar</button>

                            </div>
                        </div>

                    </form> 
                    <h5>Nao possui cadastro? <a href="#cadatroPage.php">Cadastre-se</a></h5>

                </div></div></div>







    </body></html>