<?php
require_once './shared/header.php';
?>
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
        <style>
          body{
                width: 100%;
                height: 100%;
                display: block;
                background-image: linear-gradient( to bottom, rgba(29, 91, 62) 15%, white );
         
              
            }
            .chat{
                 background-color: #FFF;
                border-radius: 10px;
                box-sizing: border-box;
                display: block;
                flex-direction: column;
                margin: 10%;
                min-height: 100%;
                padding: 25px 25px 25px 25px;
                width: 80%;
                box-shadow: 0px 4px 5px 5px rgba(0, 0, 0, 0.3);
            }
            </style>
    </head>
    <body>
        <div class="row">
            <div class="col-md-4"></div>
            <div class="col-md-4">
                <div class="chat">
                    
                    
                    
                    
                    
                </div>
            </div>
        </div>
        
        
        
        
        
        
        
        <?php
        // put your code here
        ?>
    </body>
</html>
