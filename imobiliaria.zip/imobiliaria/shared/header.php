<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">

        <link href="css/bootstrap.min.css" rel="stylesheet" type="text/css"/>
        <script src="js/bootstrap.bundle.min.js" type="text/javascript"></script>
        <script src="js/jquery-3.7.0.min.js" type="text/javascript"></script>
        <link href="css/jquery.dataTables.min.css" rel="stylesheet" type="text/css"/>
        <script src="js/jquery.dataTables.min.js" type="text/javascript"></script>
        <style>
            img{
                padding: 3px;

            }

            p{
                text-align: justify;
            }
            header{
                background-color: #000;
                color: #fff;
                display: block;
            }
        </style>

    </head>
    <body>
        <header>

            <div class="row">
                <div class="col-md-12">

                    <nav class="navbar navbar-expand-sm navbar-default">
                        <div class="container-fluid">
                            <ul class="navbar-nav">
                                <li class="nav-item">
                                    <a class="nav-link active" href="index.php"><img src="./img/logo.png" style="width:60%"></a>
                                </li>
				<!--	<a href="sobre.html">Sobre a cidade</a> <a href="hoteis.html">Hotéis</a> <a href="lugares.html">Lugares</a><a href="nos">Desenvolvedores</a> 
                                <nav>
				</nav>-->
                                <li class="nav-item">
                                    <a class="nav-link" 
                                       style="padding-top: 50px; color:#FFF;">Imoveis Rural</a> </li>
                                <li class="nav-item">
                                    <a class="nav-link" 
                                       style=" padding-top: 50px; color:#FFF;">Imoveis Urbanos</a> </li>
                                <li class="nav-item">
                                    <a class="nav-link" 
                                       style="padding-top: 50px; color:#FFF;">Quem somos?</a> </li>
                                       <li class="nav-item">
                                    <a class="nav-link" 
                                       style=" padding-top: 50px;  color:#FFF;">Chat</a> </li>
                            </ul>


                        </div></nav>



                  

                    </header>