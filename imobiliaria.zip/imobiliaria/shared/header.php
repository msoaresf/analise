<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
   
        <link href="css/bootstrap.min.css" rel="stylesheet" type="text/css"/>
        <script src="js/bootstrap.bundle.min.js" type="text/javascript"></script>
        <script src="js/jquery-3.7.0.min.js" type="text/javascript"></script>
        <link href="css/jquery.dataTables.min.css" rel="stylesheet" type="text/css"/>
        <script src="js/jquery.dataTables.min.js" type="text/javascript"></script>
        <style>
            img{
               padding: 3px;
               
            }
 
            p{
                text-align: justify;
            }
            header{
                background-color: #000; 
                height: 50%;
                color: #fff;
            }
        </style>

    </head>
    <body>
     <header>
     
        <div class="row">
            <div class="col-md-9">
                
                <ul class="nav nav-pills">
                    <li class="nav-item">
                        <img src="./img/logo.png" width="65%">
                        <a class="nav-link" href="index.php"></a>
                    </li>
                    <li class="nav-item">
                        
                        <a class="nav-link">Quem somos</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="modalPage.php">chat</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="carroucelPage.php">Rural</a>
                    </li>
                     <li class="nav-item">
                        <a class="nav-link" href="carroucelPage.php">Urbano</a>
                    </li>
                  
                    
                </ul>
            </div>
        </div>
       
               </header>