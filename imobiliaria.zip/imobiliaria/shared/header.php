<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">

 <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
        <link href="css/bootstrap.min.css" rel="stylesheet"/>
        <script src="../js/jquery.min.js" type="text/javascript"></script>
        <script src="js/bootstrap.bundle.min.js"></script>
        <script src="js/jquery-3.7.0.min.js"></script>
        <link href="css/jquery.dataTables.min.css" rel="stylesheet" />
        <script src="js/jquery.dataTables.min.js" ></script>
        <style>
           
            p{
                text-align: justify;
            }
            header{
                background-color: #0c4128;
           
                display: block;
            }
        </style>

    </head>
    <body>
        <header>

            <div class="row">
                <div class="col-md-12">

                    <nav class="navbar navbar-expand-sm navbar-default">
                        <div class="container-fluid">
                            <ul class="navbar-nav">
                                <li class="nav-item">
                                    <a class="nav-link active"  style="padding-rigth: 50%; href="index.php"><img src="./img/logo.png" style="width:50%"></a>
                                </li>
                                
                                <li class="nav-item">
                                    <a class="nav-link" 
                                       style="padding-top: 40%; text-decoration: none; font-size: 180%;  ">Imoveis Rural</a> </li>
                                <li class="nav-item">
                                    <a class="nav-link" 
                                       style=" padding-top: 32%; text-decoration: none;font-size: 180%; ">Imoveis Urbanos</a> </li>
                                <li class="nav-item">
                                    <a class="nav-link" 
                                       style="padding-top: 39%; text-decoration: none; font-size: 180%;">Quem somos?</a> </li>
                                <li class="nav-item">
                                    <a class="nav-link" 
                                       style=" padding-top: 100%; text-decoration: none; font-size: 180%;">Chat</a> </li>
                            </ul>
                        </div>

                    </nav> </div></div>





        </header>