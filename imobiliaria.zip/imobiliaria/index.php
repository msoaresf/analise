<?php
require_once './shared/header.php';
?>
<html>
    <head>
        <meta charset="UTF-8">
        <title>Marca da terra</title>
        <meta charset="utf-8">



        <style>
            .banner-area {
                width: 100%;
                height: 80%;
                position: absolute;
                background-image: url(./img/banner.jpeg);
                -webkit-background-size: cover;
                background-size: cover;
                background-position: center center;

            }

            .corpo{

                position: relative;
                padding-top: 40%;



            }

            .panel-body{
                 background-color: #F3F1F1;
            }





        </style>

    </head>

    <body>

        <div class="banner-area">
            <h3></h3>
        </div>-->
        <div class="corpo">
            <hr><br>
            <div class="container">
                <div class="jumbotron">
                    <div class="row">
                        <div class="col-md-6">
                            <h1>Procurando algum imóvel?</h1>
                            <p>Aqui você está no lugar certo!</p></div>
                        <div class="col-md-6">
                            <img style="border-radius: 10px;" width="90%" src="./img/imoveisnapraia.jpeg">
                        </div>
                    </div>
                </div>
            </div>
            <hr><br>


            <div class="row">
                <br><br>
                <div class="col-md-4">
                    <div class="panel panel-default">
                        <div class="panel-body">
                            <img  width="100%" src="./img/imoveisnapraia.jpeg"><br>
                            <h3>bladbladk</h3>
                            <p>sfasfasgdagwsahgd fas
                                sgasgsg
                                gasgasg</p><br><br><br>
                        </div>
                    </div>
                </div>

                <div class="col-md-4">
                    <div class="panel panel-default">
                        <div class="panel-body">
                            <img width="100%"src="./img/imoveisnapraia.jpeg"><br>
                            <h3>bladbladk</h3>
                            <p>sfasfasgdagwsahgd fas
                                sgasgsg
                                gasgasg</p><br><br><br>
                        </div>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="panel panel-default">
                        <div class="panel-body">
                            <img width="100%" src="./img/imoveisnapraia.jpeg"><br>
                            <h3>bladbladk</h3>
                            <p>sfasfasgdagwsahgd fas
                                sgasgsg
                                gasgasg</p><br><br><br>
                        </div>
                    </div>
                </div>
            </div>
            <br><br>
            
            <div class="row">
                <br><br>
                <div class="col-md-4">
                    <div class="panel panel-default">
                        <div class="panel-body">
                            <img  width="100%" src="./img/imoveisnapraia.jpeg"><br>
                            <h3>bladbladk</h3>
                            <p>sfasfasgdagwsahgd fas
                                sgasgsg
                                gasgasg</p><br><br><br>
                        </div>
                    </div>
                </div>

                <div class="col-md-4">
                    <div class="panel panel-default">
                        <div class="panel-body">
                            <img width="100%"src="./img/imoveisnapraia.jpeg"><br>
                            <h3>bladbladk</h3>
                            <p>sfasfasgdagwsahgd fas
                                sgasgsg
                                gasgasg</p><br><br><br>
                        </div>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="panel panel-default">
                        <div class="panel-body">
                            <img width="100%" src="./img/imoveisnapraia.jpeg"><br>
                            <h3>bladbladk</h3>
                            <p>sfasfasgdagwsahgd fas
                                sgasgsg
                                gasgasg</p><br><br><br>
                        </div>
                    </div>
                </div>
            </div>
            <br><br>
            
            <div class="row">
                <br><br>
                <div class="col-md-4">
                    <div class="panel panel-default">
                        <div class="panel-body">
                            <img  width="100%" src="./img/imoveisnapraia.jpeg"><br>
                            <h3>bladbladk</h3>
                            <p>sfasfasgdagwsahgd fas
                                sgasgsg
                                gasgasg</p><br><br><br>
                        </div>
                    </div>
                </div>

                <div class="col-md-4">
                    <div class="panel panel-default">
                        <div class="panel-body">
                            <img width="100%"src="./img/imoveisnapraia.jpeg"><br>
                            <h3>bladbladk</h3>
                            <p>sfasfasgdagwsahgd fas
                                sgasgsg
                                gasgasg</p><br><br><br>
                        </div>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="panel panel-default">
                        <div class="panel-body">
                            <img width="100%" src="./img/imoveisnapraia.jpeg"><br>
                            <h3>bladbladk</h3>
                            <p>sfasfasgdagwsahgd fas
                                sgasgsg
                                gasgasg</p><br><br><br>
                        </div>
                    </div>
                </div>
            </div>
            <br><br>

        </div>
        <?php
        // put your code here
        ?>
    </body>
</html>
