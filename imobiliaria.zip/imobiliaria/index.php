<?php
require_once './shared/header.php';
?>
<html>
    <head>
        <meta charset="UTF-8">
        <title>Marca da terra</title>
    </head>
    <body>
        <?php
        // put your code here
        ?>
    </body>
</html>
