<?php
require_once './shared/header.php';
?>
<html>
    <head>
        <meta charset="UTF-8">
        <title>Marca da terra</title>
        <style>
            .banner-area {
                width: 100%;
                height: 60%;
                position: absolute;
                background-image: url(./img/banner.jpeg);
                -webkit-background-size: cover;
                background-size: cover;
                background-position: center center;

            }






.imovel {
  display: flex;
  align-items: center;
  width: 30%;
  position: relative;
  bottom: 50%: 
  
 
  }
  
  
  .entry {
  display: flex;
  align-items: center;
  flex-direction:column;
  position: relative;
  width: 80%;
  background: #fff;
  margin: 2em;
  padding: 0.5em;
  border-radius: 10px;
  box-shadow: 4px 4px 5px 0px rgba(0, 0, 0, 0.5);
}

        </style>

    </head>

    <body>
        <div class="banner-area">
            <h3></h3>
        </div>

         <div class="imovel">
    <div class="entry">
      <p class="name">Ruby Emma Hotel Amsterdam</p>
      <img  src="https://cf.bstatic.com/xdata/images/hotel/max1024x768/360146980.jpg?k=9f4a1631d64d7be498226341b4493604f05e121af8ccf7d5fa9b80aef8b70e81&o=&hp=1" width="90%" />
      <p class="quote">O Ruby Emma Hotel Amsterdam está localizado à beira do Rio Amstel, em Amsterdã. Este hotel combina luxo, tecnologia e sustentabilidade em um edifício moldado pela natureza. O Wi-Fi é grátis em todos os ambientes. Há banheiro privativo no qual conta com diversos produtos da Ruby Care.</p>
      
    </div></div>
        <?php
        // put your code here
        ?>
    </body>
</html>
