<?php
require_once './shared/header.php';
?>
<html>
    <head>
        <meta charset="UTF-8">
        <title>Marca da terra</title>
        <meta charset="utf-8">



        <style>
            body{
                 background-color: #dee2e6;
            }
            .banner-area {
                width: 100%;
                height: 80%;
                position: absolute;
                background-image: url(./img/banner.jpeg);
                -webkit-background-size: cover;
                background-size: cover;
                background-position: center center;
               

            }

            .corpo{

                position: relative;
                padding-top: 40%;



            }

           
            .imovel{
                background-color: #FFF;
                border-radius: 10px;
                box-sizing: border-box;
                display: block;
                flex-direction: column;
                margin: 10%;
                min-height: 100%;
                padding: 25px 25px 25px 25px;
                width: 80%;
                box-shadow: 0px 4px 5px 5px rgba(0, 0, 0, 0.3);
            }




        </style>

    </head>

    <body>

        <div class="banner-area">
            <h3></h3>
        </div>
        <div class="corpo">
            <hr><br>
            <div class="container">
                <div style="color:" class="jumbotron">
                    <div class="row">
                        <div class="col-md-6">
                            <h1>Procurando algum imóvel?</h1>
                            <p>Aqui você está no lugar certo!</p></div>
                        <div class="col-md-6">
                            <img style="border-radius: 10px;" width="90%" src="./img/imoveisnapraia.jpeg">
                        </div>
                    </div>
                </div>
            </div>
            <hr><br>

            <div class="row">
                <div class="col-md-3"></div>
                  <div class="col-md-8">
                    <h1 style="color: #0c4128; font-size: 40px;">Confira nossa seleçao de imóveis em destaque para você!</h1>                    
                    
                    
                </div></div>

            <div class="row">
                <br><br>
                <div class="col-md-4">
                    <div class="imovel">
                        <img  width="100%" src="./img/imoveisnapraia.jpeg"><br>
                        <h3>bladbladk</h3>
                        <p>sfasfasgdagwsahgd fas
                            sgasgsg
                            gasgasg</p><br><br><br>
                    </div>
                </div>

                <div class="col-md-4">
                    <div class="imovel">
                        <img  width="100%" src="./img/imoveisnapraia.jpeg"><br>
                        <h3>bladbladk</h3>
                        <p>sfasfasgdagwsahgd fas
                            sgasgsg
                            gasgasg</p><br><br><br>
                    </div>
                </div>

                <div class="col-md-4">
                    <div class="imovel">
                        <img  width="100%" src="./img/imoveisnapraia.jpeg"><br>
                        <h3>bladbladk</h3>
                        <p>sfasfasgdagwsahgd fas
                            sgasgsg
                            gasgasg</p><br><br><br>
                    </div>
                </div></div>

            <br><br>

            <div class="row">
                <br><br>
                <div class="col-md-4">
                    <div class="imovel">
                        <img  width="100%" src="./img/imoveisnapraia.jpeg"><br>
                        <h3>bladbladk</h3>
                        <p>sfasfasgdagwsahgd fas
                            sgasgsg
                            gasgasg</p><br><br><br>
                    </div>
                </div>


                <div class="col-md-4">
                    <div class="imovel">
                        <img  width="100%" src="./img/imoveisnapraia.jpeg"><br>
                        <h3>bladbladk</h3>
                        <p>sfasfasgdagwsahgd fas
                            sgasgsg
                            gasgasg</p><br><br><br>
                    </div>
                </div>

                <div class="col-md-4">
                    <div class="imovel">
                        <img  width="100%" src="./img/imoveisnapraia.jpeg"><br>
                        <h3>bladbladk</h3>
                        <p>sfasfasgdagwsahgd fas
                            sgasgsg
                            gasgasg</p><br><br><br>
                    </div>
                </div>
            </div>

            <br><br>

            <div class="row">
                <br><br>
                <div class="col-md-4">
                    <div class="imovel">
                        <img  width="100%" src="./img/imoveisnapraia.jpeg"><br>
                        <h3>bladbladk</h3>
                        <p>sfasfasgdagwsahgd fas
                            sgasgsg
                            gasgasg</p><br><br><br>
                    </div>
                </div>


                <div class="col-md-4">
                    <div class="imovel">
                        <img  width="100%" src="./img/imoveisnapraia.jpeg"><br>
                        <h3>bladbladk</h3>
                        <p>sfasfasgdagwsahgd fas
                            sgasgsg
                            gasgasg</p><br><br><br>
                    </div>
                </div>

                <div class="col-md-4">
                    <div class="imovel">
                        <img  width="100%" src="./img/imoveisnapraia.jpeg"><br>
                        <h3>bladbladk</h3>
                        <p>sfasfasgdagwsahgd fas
                            sgasgsg
                            gasgasg</p><br><br><br>
                    </div>
                </div>

            </div>
            <br><br>

        </div>
        <?php
    /* 
   $apartamentos = array(
            array('id' => 1, 'imagem' => ''),
            array('id' => 2, 'imagem' => ''),
            array('id' => 3,  'imagem' => ''),
            array('id' => 4,  'imagem' => ''),
            array('id' => 5,  'imagem' => ''),
            array('id' => 6,  'imagem' => '')
        );
   $fazendas = array(
            array('id' => 1, 'imagem' => 'img/series/serie1.png'),
            array('id' => 2, 'imagem' => 'img/series/serie2.png'),
            array('id' => 3,  'imagem' => 'img/series/serie3.png'),
            array('id' => 4,  'imagem' => 'img/series/serie4.png'),
            array('id' => 5,  'imagem' => 'img/series/serie5.png'),
           array('id' => 6,  'imagem' => 'img/series/serie6.png')
        );
    $casa = array(
            array('id' => 1, 'imagem' => 'img/infantil/infantil1.png'),
            array('id' => 2, 'imagem' => 'img/infantil/infantil2.png'),
            array('id' => 3,  'imagem' => 'img/infantil/infantil3.png'),
            array('id' => 4,  'imagem' => 'img/infantil/infantil4.png'),
            array('id' => 5,  'imagem' => 'img/infantil/infantil5.png'),
           array('id' => 6,  'imagem' => 'img/infantil/infantil6.png')
        );
     $infantil = array(
            array('id' => 1, 'imagem' => 'img/infantil/infantil7.png'),
            array('id' => 2, 'imagem' => 'img/infantil/infantil8.png'),
            array('id' => 3,  'imagem' => 'img/infantil/infantil9.png'),
            array('id' => 4,  'imagem' => 'img/infantil/infantil10.png'),
            array('id' => 5,  'imagem' => 'img/infantil/infantil11.png'),
            array('id' => 6,  'imagem' => 'img/infantil/infantil12.png')
        );
   
    @$conta = $_REQUEST['conta'];
        if (isset($conta)) {
            if ($conta == '3') {   //perfil infantil
                echo('<div class=row>');
                echo('<h3>Assistir Novamente:</h3>');

                foreach ($infantil2 as $data3) {

                    echo('<div class="col-md-2 zoom">');
                    echo('<img src=" ' . $data3['imagem'] . ' " style="width:100%;"/>');
                    echo('</div>');
                }

                echo('</div>');

                echo('<div class=row>');
                echo('<h3>Popular:</h3>');

                foreach ($infantil as $data4) {

                    echo('<div class="col-md-2 zoom">');
                    echo('<img src=" ' . $data4['imagem'] . ' " style="width:100%;"/>');
                    echo('</div>');
                }
                echo('</div>');
                
            } else if ($conta == '2' || $conta == '1') {  //perfil adulto
                echo('<div class=row>');
                echo('<h3>Filmes:</h3>');

                foreach ($filmes as $data) {

                    echo('<div class="col-md-2 zoom">');
                    echo('<img src=" ' . $data['imagem'] . ' " style="width:100%;"/>');
                    echo('</div>');
                }

                echo('</div>');

                echo('<div class=row>');
                echo('<h3>Séries:</h3>');

                foreach ($serie as $data2) {

                    echo('<div class="col-md-2 zoom">');
                    echo('<img src=" ' . $data2['imagem'] . ' " style="width:100%;"/>');
                    echo('</div>');
                }
                echo('</div>');
            }
        }
*/
      ?>
        ?>
    </body>
</html>
