<?php
require_once './shared/header.php';
?>
<html>
    <head>
        <meta charset="UTF-8">
        <title>Marca da terra</title>
        <meta charset="utf-8">
    </head>
    <body>
        <br>  <br>  <br>  <br> <br> <br> <br>
        <div class="row">
            <div class="col-md-2"></div>
            <div class="col-md-3">
                <h2> Quem Somos</h2>
                <p style="font-size: 150%">
Iniciando nossa história em 2008 com o corretor
imobiliário Juliano Pacheco Ferreira, junto dele a força e o profissionalismo para buscar os melhores resultados assim criando destaque no mercado imobiliário pela seriedade, transparência, bom atendimento e dedicação.

Com o objetivo de tornar-se mais ágil a aquisição de imóveis, áreas rurais e terrenos urbanos nós atuamos na intermediação de compra e venda, avaliação, agenciamento de áreas, correspondente bancário (financiamento, consórcios e consignados).

Com a evolução do mercado, aliado à credibilidade e competência, fez com que Juliano criasse a sua marca e se desenvolvesse rapidamente com as inovações, passando a atuar pelo nome MARCA DA TERRA AGRONEGÓCIOS.

Sendo anos de treinamento, e com um método próprio de formação de equipe, formando analistas, corretores e consultores especializados para facilitar os seus negócios. Além de sermos comprometidos com a excelência e qualidade dos nossos serviços, também cuidamos e protegemos o patrimônio dos nossos clientes!

NOSSOS PRINCÍPIOS
Inovação, eficiência, transparência, ética, credibilidade e responsabilidade
                    
                </p>
            </div>
            <div class="col-md-4">
                <img  width="140%" style="padding-left: 15%; padding-top: 4% " src="./img/quemsomosimg.jpeg">
            </div>
        </div>
        
        
        
        
        <?php
       
        ?>
    </body>
</html>
