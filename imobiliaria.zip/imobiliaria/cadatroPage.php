<?php
require_once './shared/header.php';
?>
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <div class="col-md-4"> </div>
            <div class="col-md-4"><br><br><br><br>
                <div class="row" style="padding: 10px">

                    <h1 style="">Cadastrar-se</h1><br>

                    <form method="post" action=".php">
                        <label style="" for="email" class="form-label">Email:</label>
                        <br>
                        <input type="password" class="form-control" id="Email"  placeholder="Senha" name="senha" required="">

                        <br>
                        <label style="" for="email" class="form-label">Senha:</label>
                        <br>
                        <input type="password" class="form-control" id="senha"  placeholder="Senha" name="senha" required="">

                        <div class="mb- mt-3">
                            <div class="d-grid">
                                <button type="submit"class="btn btn-danger">Criar conta</button>
                            </div>
                        </div>

                    </form>




                </div>   
            </div></div></div>


        <?php
        // put your code here
        ?>
    </body>
</html>
