<?php
require_once './shared/header.php';
?>
<html>
    <head>
        <meta charset="UTF-8">
        <title>Marca da terra</title>
        <meta charset="utf-8">
        <style>
            body{
                width: 100%;
                height: 100%;
                display: block;
                background-image: linear-gradient( to bottom, rgba(29, 91, 62) 30%, white );
            }
            .contato{
                background-color: rgba(255, 255, 255);
                border-radius: 10px;
                box-sizing: border-box;
                display: block;
                flex-direction: column;
                margin: 10%;
                min-height: 80%;
                padding: 0px 20px 40px;
                width: 60%;

            }
            .descri{
                background-color: rgba(255, 255, 255);
                border-radius: 10px;
                box-sizing: border-box;
                flex-direction: column;
                margin: 0%;
                min-height: 100%;
                padding: 0px 20px 40px;
                width: 100%;

                
                
            }
        </style>

    </head>
    <body>
        <br><br>
        <div class="row">
            <div class="col-md-1"></div>
            <div class="col-md-6">
                <br>
                <br>
                <br>
                <div class="container">
                    <div id="myCarousel" class="carousel slide" data-ride="carousel">
                        <!-- indicadores-->
                        <ol class="carousel-indicators">
                            <li data-target="#myCarousel" data-slide-to="0" class="active"></li>
                            <li data-target="#myCarousel" data-slide-to="1"></li>
                            <li data-target="#myCarousel" data-slide-to="2"></li>
                        </ol>

                        <!-- fotos -->
                        <div class="carousel-inner">
                            <div class="item active">
                                <img src="./img/imoveisnapraia.jpeg" style="width:100%;">
                            </div>

                            <div class="item">
                                <img src="./img/imoveisnapraia.jpeg" alt="" style="width:100%;">
                            </div>

                            <div class="item">
                                <img src="./img/imoveisnapraia.jpeg" alt="" style="width:100%;">
                            </div>
                        </div>

                        <!-- contolr pra passar-->
                        <a class="left carousel-control" href="#myCarousel" data-slide="prev">
                            <span class="glyphicon glyphicon-chevron-left"></span>
                            <span class="sr-only"></span>
                        </a>
                        <a class="right carousel-control" href="#myCarousel" data-slide="next">
                            <span class="glyphicon glyphicon-chevron-right"></span>
                            <span class="sr-only"></span>
                        </a>
                    </div>
                </div>
            </div>


            <div class="col-md-5">

                <div class="contato">
                    <br><br>
                    <h2>Contato</h2><br>
                    <form>
                        <p>Nome:</p>
                        <input type="text" class="form-control" id="nome_msg" placeholder="Nome" name="nome_msg"><br>
                        <p>Email:</p>
                        <input type="text" class="form-control" id="email_msg" placeholder="Nome" name="email_msg"><br>
                        <p>Codigo do imóvel:</p>
                        <input type="text" class="form-control" id="msg" name="msg" placeholder="Codigo do imovel (Pode ser encontrado sob o nome do imóvel"> <br>

                        <div class="d-grid">
                            <button width="100%" value="submit" type="button" class="btn btn-success">Enviar</button></div>
                    </form>
                </div>
            </div>
        </div>
        <div class="row">

            <div class="col-md-1"></div>
            <div class="col-md-6">
                <div class="descri">
                    <br>
                    <br>
                    <h1>Descrição</h1>
                    <hr>
                    <h5>nfkaslfnskalfnsaklfnaskfnskalf
                    sagnlsanglaksnglsgnasklg
                    asglnaskgnasl</h5>
                    
                </div>




            </div>
        </div>




    </body>
</html>