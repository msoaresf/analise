<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
   
        <link href="css/bootstrap.min.css" rel="stylesheet" type="text/css"/>
        <script src="js/bootstrap.bundle.min.js" type="text/javascript"></script>
        <script src="js/jquery-3.7.0.min.js" type="text/javascript"></script>
        <link href="css/jquery.dataTables.min.css" rel="stylesheet" type="text/css"/>
        <script src="js/jquery.dataTables.min.js" type="text/javascript"></script>
        <style>
            .div-block-78 detalhes detalhe{
               -webkit-text-size-adjust: 100%;
    font-family: Arial, sans-serif;
    font-size: 14px;
    line-height: 20px;
    color: #333;
    box-sizing: border-box;
    padding-bottom: 100px;
    padding-top: 50px;
            }
        </style>

    </head>
    <body>
 
    </body>
</html>