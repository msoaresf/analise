<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
   
        <link href="css/bootstrap.min.css" rel="stylesheet" type="text/css"/>
        <script src="js/bootstrap.bundle.min.js" type="text/javascript"></script>
        <script src="js/jquery-3.7.0.min.js" type="text/javascript"></script>
        <link href="css/jquery.dataTables.min.css" rel="stylesheet" type="text/css"/>
        <script src="js/jquery.dataTables.min.js" type="text/javascript"></script>
        <style>
            .div-block-78 detalhes detalhe{
               -webkit-text-size-adjust: 100%;
    font-family: Arial, sans-serif;
    font-size: 14px;
    line-height: 20px;
    color: #333;
    box-sizing: border-box;
    padding-bottom: 100px;
    padding-top: 50px;
            }
        </style>

    </head>
    <body>
    <div class="div-block-78 detalhes detalhe">
    <div class="div-block-80">
      <div class="w-layout-grid grid-3">
        <div>
          <div class="gallery-wrap">
            <div class="div-block-56">
              <div data-animation="slide" data-duration="500" data-infinite="1" class="slider-2 w-slider" role="region" aria-label="carousel">
                <div class="mask-2 w-slider-mask" id="w-slider-mask-0"><div class="slide-6 w-slide" aria-label="1 of 11" role="group" style="transform: translateX(-5918.25px); opacity: 1;" aria-hidden="true"><a href="https://si9dados.com.br/si9-fotos/marcadaterra/16976318064501697631806364db2fb4d2-a911-4b0f-b714-d4e320252ced.jpeg" class="link-block w-inline-block" data-fancybox="gallery1" tabindex="-1" aria-hidden="true">
                      <img src="https://si9dados.com.br/si9-fotos/marcadaterra/16976318064501697631806364db2fb4d2-a911-4b0f-b714-d4e320252ced.jpeg" loading="lazy" alt="" class="image-40" aria-hidden="true"></a>
                  </div><div class="slide-6 w-slide" aria-label="2 of 11" role="group" style="transform: translateX(-5918.25px); opacity: 1;" aria-hidden="true"><a href="https://si9dados.com.br/si9-fotos/marcadaterra/169763180397116976318038653b88dad4-da03-4c98-a8e7-49f08954f009.jpeg" class="link-block w-inline-block" data-fancybox="gallery1" tabindex="-1" aria-hidden="true">
                      <img src="https://si9dados.com.br/si9-fotos/marcadaterra/169763180397116976318038653b88dad4-da03-4c98-a8e7-49f08954f009.jpeg" loading="lazy" alt="" class="image-40" aria-hidden="true"></a>
                  </div><div class="slide-6 w-slide" aria-label="3 of 11" role="group" style="transform: translateX(-5918.25px); opacity: 1;" aria-hidden="true"><a href="https://si9dados.com.br/si9-fotos/marcadaterra/16976318075741697631807491f5d66038-33f5-49e1-8d6c-2ce82e9ed289.jpeg" class="link-block w-inline-block" data-fancybox="gallery1" tabindex="-1" aria-hidden="true">
                      <img src="https://si9dados.com.br/si9-fotos/marcadaterra/16976318075741697631807491f5d66038-33f5-49e1-8d6c-2ce82e9ed289.jpeg" loading="lazy" alt="" class="image-40" aria-hidden="true"></a>
                  </div><div class="slide-6 w-slide" aria-label="4 of 11" role="group" style="transform: translateX(-5918.25px); opacity: 1;" aria-hidden="true"><a href="https://si9dados.com.br/si9-fotos/marcadaterra/169763185285116976318527268ca017e5-9c62-47e4-971e-1cddf0663a86.jpeg" class="link-block w-inline-block" data-fancybox="gallery1" tabindex="-1" aria-hidden="true">
                      <img src="https://si9dados.com.br/si9-fotos/marcadaterra/169763185285116976318527268ca017e5-9c62-47e4-971e-1cddf0663a86.jpeg" loading="lazy" alt="" class="image-40" aria-hidden="true"></a>
                  </div><div class="slide-6 w-slide" aria-label="5 of 11" role="group" style="transform: translateX(-5918.25px); opacity: 1;" aria-hidden="true"><a href="https://si9dados.com.br/si9-fotos/marcadaterra/16976315716061697631570277CasaLuizGuilherme.jpg" class="link-block w-inline-block" data-fancybox="gallery1" tabindex="-1" aria-hidden="true">
                      <img src="https://si9dados.com.br/si9-fotos/marcadaterra/16976315716061697631570277CasaLuizGuilherme.jpg" loading="lazy" alt="" class="image-40" aria-hidden="true"></a>
                  </div><div class="slide-6 w-slide" aria-label="6 of 11" role="group" style="transform: translateX(-5918.25px); opacity: 1;" aria-hidden="true"><a href="https://si9dados.com.br/si9-fotos/marcadaterra/16976315732281697631573038Screenshot_15.jpg" class="link-block w-inline-block" data-fancybox="gallery1" tabindex="-1" aria-hidden="true">
                      <img src="https://si9dados.com.br/si9-fotos/marcadaterra/16976315732281697631573038Screenshot_15.jpg" loading="lazy" alt="" class="image-40" aria-hidden="true"></a>
                  </div><div class="slide-6 w-slide" aria-label="7 of 11" role="group" style="transform: translateX(-5918.25px); opacity: 1;" aria-hidden="true"><a href="https://si9dados.com.br/si9-fotos/marcadaterra/169763597068716976359703512.jpeg" class="link-block w-inline-block" data-fancybox="gallery1" tabindex="-1" aria-hidden="true">
                      <img src="https://si9dados.com.br/si9-fotos/marcadaterra/169763597068716976359703512.jpeg" loading="lazy" alt="" class="image-40" aria-hidden="true"></a>
                  </div><div class="slide-6 w-slide" aria-label="8 of 11" role="group" style="transform: translateX(-5918.25px); opacity: 1;" aria-hidden="true"><a href="https://si9dados.com.br/si9-fotos/marcadaterra/169763597214216976359718313.jpeg" class="link-block w-inline-block" data-fancybox="gallery1" tabindex="-1" aria-hidden="true">
                      <img src="https://si9dados.com.br/si9-fotos/marcadaterra/169763597214216976359718313.jpeg" loading="lazy" alt="" class="image-40" aria-hidden="true"></a>
                  </div><div class="slide-6 w-slide" aria-label="9 of 11" role="group" style="transform: translateX(-5918.25px); opacity: 1;"><a href="https://si9dados.com.br/si9-fotos/marcadaterra/169763597409216976359737894.jpeg" class="link-block w-inline-block" data-fancybox="gallery1">
                      <img src="https://si9dados.com.br/si9-fotos/marcadaterra/169763597409216976359737894.jpeg" loading="lazy" alt="" class="image-40"></a>
                  </div><div class="slide-6 w-slide" aria-label="10 of 11" role="group" aria-hidden="true" style="transform: translateX(-5918.25px); opacity: 1;"><a href="https://si9dados.com.br/si9-fotos/marcadaterra/169763597704316976359767366.jpeg" class="link-block w-inline-block" data-fancybox="gallery1" tabindex="-1" aria-hidden="true">
                      <img src="https://si9dados.com.br/si9-fotos/marcadaterra/169763597704316976359767366.jpeg" loading="lazy" alt="" class="image-40" aria-hidden="true"></a>
                  </div><div class="slide-6 w-slide" aria-label="11 of 11" role="group" aria-hidden="true" style="transform: translateX(-5918.25px); opacity: 1;"><a href="https://si9dados.com.br/si9-fotos/marcadaterra/169763597956416976359792577.jpeg" class="link-block w-inline-block" data-fancybox="gallery1" tabindex="-1" aria-hidden="true">
                      <img src="https://si9dados.com.br/si9-fotos/marcadaterra/169763597956416976359792577.jpeg" loading="lazy" alt="" class="image-40" aria-hidden="true"></a>
                  </div><div aria-live="off" aria-atomic="true" class="w-slider-aria-label" data-wf-ignore="">Slide 9 of 11.</div></div>
                <div class="left-arrow-2 w-slider-arrow-left" role="button" tabindex="0" aria-controls="w-slider-mask-0" aria-label="previous slide">
                  <div class="w-icon-slider-left"></div>
                </div>
                <div class="right-arrow-2 w-slider-arrow-right" role="button" tabindex="0" aria-controls="w-slider-mask-0" aria-label="next slide">
                  <div class="w-icon-slider-right"></div>
                </div>
                <div class="slide-nav-2 w-slider-nav w-round"><div class="w-slider-dot" data-wf-ignore="" aria-label="Show slide 1 of 11" aria-selected="false" role="button" tabindex="-1"></div><div class="w-slider-dot" data-wf-ignore="" aria-label="Show slide 2 of 11" aria-selected="false" role="button" tabindex="-1"></div><div class="w-slider-dot" data-wf-ignore="" aria-label="Show slide 3 of 11" aria-selected="false" role="button" tabindex="-1"></div><div class="w-slider-dot" data-wf-ignore="" aria-label="Show slide 4 of 11" aria-selected="false" role="button" tabindex="-1"></div><div class="w-slider-dot" data-wf-ignore="" aria-label="Show slide 5 of 11" aria-selected="false" role="button" tabindex="-1"></div><div class="w-slider-dot" data-wf-ignore="" aria-label="Show slide 6 of 11" aria-selected="false" role="button" tabindex="-1"></div><div class="w-slider-dot" data-wf-ignore="" aria-label="Show slide 7 of 11" aria-selected="false" role="button" tabindex="-1"></div><div class="w-slider-dot" data-wf-ignore="" aria-label="Show slide 8 of 11" aria-selected="false" role="button" tabindex="-1"></div><div class="w-slider-dot w-active" data-wf-ignore="" aria-label="Show slide 9 of 11" aria-selected="true" role="button" tabindex="0"></div><div class="w-slider-dot" data-wf-ignore="" aria-label="Show slide 10 of 11" aria-selected="false" role="button" tabindex="-1"></div><div class="w-slider-dot" data-wf-ignore="" aria-label="Show slide 11 of 11" aria-selected="false" role="button" tabindex="-1"></div></div>
              </div>
            </div>
            <div class="gallery-wrapper"></div>
          </div>

<!--            -->




                    <div class="white-block">
            <div class="title-block">
              <h3 class="heading-12">Descrição</h3>
            </div>
            <div class="content-wrapper">
              <div class="text-block-7">Residência de Alto Padrão em Condomínio Fechado - Real Park<br><br>Esta casa de alto padrão no condomínio fechado Royal Park é uma <br>verdadeira joia arquitetônica. <br>A abundante iluminação realçando todo seu espaço, criando uma<br> visual calmo e tranquilo de estar. <br>O amplo living se integra harmoniosamente ao exuberante jardim,<br> proporcionando um espaço versátil e convidativo.<br><br>Características do Imóvel:<br>3 suítes, sendo uma térrea,17 m², 21 m² e 37 m², a maior espaço closet<br> consequentemente as suítes espaçosas para noites de descanso tranquilo.<br>Cozinha americana e área de serviço bem planejadas.<br>Espera para sistema de ar-condicionado Split para máximo conforto.<br>Ambiente aconchegante com lareira, perfeito para momentos de relaxamento.<br>Quintal e churrasqueira para encontros memoráveis com amigos e familiares.<br>Suíte máster com espaço e elegância sem igual.<br>Sala de TV e sala de jantar para entretenimento e convívio.<br><br>Infraestrutura do Condomínio:<br>Estacionamento para comodidade dos moradores.<br>Portaria 24 horas e segurança patrimonial para total tranquilidade.<br>Playground e áreas de lazer para diversão das crianças.<br><br>Quadra de esportes e quadra de tênis para os amantes do esporte.<br>Jardins e quiosques para momentos de contemplação.<br><br>Esta casa é uma verdadeira obra-prima, construída com materiais<br>nobres e atenção aos detalhes. Venha conhecer este oásis de luxo <br>e sofisticação.<br><br>Entrega da obra Fevereiro de 2024.<br><br> Agende uma visita hoje mesmo!<br><br>Ótima Oportunidade !!! Agende conosco e vamos visitar este lindo<br><br>Terreno em bairro aberto e planejado.<br><br>CORRETORA VANIA<br>(55) 99945.1311<br><br>JULIANO PACHECO FERREIRA<br>(55) 99699.2757</div>
            </div>
          </div>

          
      


               <!--                  <div class='white-block'> <div class='title-block'> <h3 class='heading-12'>C�modos</h3> </div> 

                 </div>
                   -->


                                <div class="white-block"> <div class="title-block"> <h3 class="heading-12">Características</h3> </div> <div class="content-wrapper"> <div class="w-layout-grid feature-grid">
                  
                <div class="feature-wrap">
                  <svg class="filter-icon" width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="https://www.w3.org/2000/svg">
                  <path fill-rule="evenodd" clip-rule="evenodd" d="M0 8C0 3.58172 3.58172 0 8 0C12.4161 0.00514317 15.9949 3.58385 16 8C16 12.4183 12.4183 16 8 16C3.58172 16 0 12.4183 0 8ZM8.05467 11.6593L12.618 5.46667C12.7723 5.27572 12.8091 5.01545 12.7139 4.78918C12.6187 4.56291 12.4069 4.40726 12.1625 4.38403C11.9182 4.36079 11.6808 4.47373 11.5447 4.678L7.39333 10.312L4.676 8.138C4.38844 7.90788 3.96879 7.95444 3.73867 8.242C3.50855 8.52956 3.55511 8.94921 3.84267 9.17933L7.10133 11.7847C7.24379 11.896 7.42501 11.9455 7.60428 11.9219C7.78355 11.8983 7.94584 11.8037 8.05467 11.6593Z" fill="#1f1f1f"></path></svg>
                <div>
                  
                 <b></b> Portão Eletrônico<br>                </div>
              </div>

              
                <div class="feature-wrap">
                  <svg class="filter-icon" width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="https://www.w3.org/2000/svg">
                  <path fill-rule="evenodd" clip-rule="evenodd" d="M0 8C0 3.58172 3.58172 0 8 0C12.4161 0.00514317 15.9949 3.58385 16 8C16 12.4183 12.4183 16 8 16C3.58172 16 0 12.4183 0 8ZM8.05467 11.6593L12.618 5.46667C12.7723 5.27572 12.8091 5.01545 12.7139 4.78918C12.6187 4.56291 12.4069 4.40726 12.1625 4.38403C11.9182 4.36079 11.6808 4.47373 11.5447 4.678L7.39333 10.312L4.676 8.138C4.38844 7.90788 3.96879 7.95444 3.73867 8.242C3.50855 8.52956 3.55511 8.94921 3.84267 9.17933L7.10133 11.7847C7.24379 11.896 7.42501 11.9455 7.60428 11.9219C7.78355 11.8983 7.94584 11.8037 8.05467 11.6593Z" fill="#1f1f1f"></path></svg>
                <div>
                  
                 <b></b> Caixa Água<br>                </div>
              </div>

              
                <div class="feature-wrap">
                  <svg class="filter-icon" width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="https://www.w3.org/2000/svg">
                  <path fill-rule="evenodd" clip-rule="evenodd" d="M0 8C0 3.58172 3.58172 0 8 0C12.4161 0.00514317 15.9949 3.58385 16 8C16 12.4183 12.4183 16 8 16C3.58172 16 0 12.4183 0 8ZM8.05467 11.6593L12.618 5.46667C12.7723 5.27572 12.8091 5.01545 12.7139 4.78918C12.6187 4.56291 12.4069 4.40726 12.1625 4.38403C11.9182 4.36079 11.6808 4.47373 11.5447 4.678L7.39333 10.312L4.676 8.138C4.38844 7.90788 3.96879 7.95444 3.73867 8.242C3.50855 8.52956 3.55511 8.94921 3.84267 9.17933L7.10133 11.7847C7.24379 11.896 7.42501 11.9455 7.60428 11.9219C7.78355 11.8983 7.94584 11.8037 8.05467 11.6593Z" fill="#1f1f1f"></path></svg>
                <div>
                  
                 <b></b> Churrasqueira<br>                </div>
              </div>

              
                <div class="feature-wrap">
                  <svg class="filter-icon" width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="https://www.w3.org/2000/svg">
                  <path fill-rule="evenodd" clip-rule="evenodd" d="M0 8C0 3.58172 3.58172 0 8 0C12.4161 0.00514317 15.9949 3.58385 16 8C16 12.4183 12.4183 16 8 16C3.58172 16 0 12.4183 0 8ZM8.05467 11.6593L12.618 5.46667C12.7723 5.27572 12.8091 5.01545 12.7139 4.78918C12.6187 4.56291 12.4069 4.40726 12.1625 4.38403C11.9182 4.36079 11.6808 4.47373 11.5447 4.678L7.39333 10.312L4.676 8.138C4.38844 7.90788 3.96879 7.95444 3.73867 8.242C3.50855 8.52956 3.55511 8.94921 3.84267 9.17933L7.10133 11.7847C7.24379 11.896 7.42501 11.9455 7.60428 11.9219C7.78355 11.8983 7.94584 11.8037 8.05467 11.6593Z" fill="#1f1f1f"></path></svg>
                <div>
                  
                 <b></b> Alarme<br>                </div>
              </div>

              
                <div class="feature-wrap">
                  <svg class="filter-icon" width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="https://www.w3.org/2000/svg">
                  <path fill-rule="evenodd" clip-rule="evenodd" d="M0 8C0 3.58172 3.58172 0 8 0C12.4161 0.00514317 15.9949 3.58385 16 8C16 12.4183 12.4183 16 8 16C3.58172 16 0 12.4183 0 8ZM8.05467 11.6593L12.618 5.46667C12.7723 5.27572 12.8091 5.01545 12.7139 4.78918C12.6187 4.56291 12.4069 4.40726 12.1625 4.38403C11.9182 4.36079 11.6808 4.47373 11.5447 4.678L7.39333 10.312L4.676 8.138C4.38844 7.90788 3.96879 7.95444 3.73867 8.242C3.50855 8.52956 3.55511 8.94921 3.84267 9.17933L7.10133 11.7847C7.24379 11.896 7.42501 11.9455 7.60428 11.9219C7.78355 11.8983 7.94584 11.8037 8.05467 11.6593Z" fill="#1f1f1f"></path></svg>
                <div>
                  
                 <b></b> Cerca Elétrica<br>                </div>
              </div>

              
                <div class="feature-wrap">
                  <svg class="filter-icon" width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="https://www.w3.org/2000/svg">
                  <path fill-rule="evenodd" clip-rule="evenodd" d="M0 8C0 3.58172 3.58172 0 8 0C12.4161 0.00514317 15.9949 3.58385 16 8C16 12.4183 12.4183 16 8 16C3.58172 16 0 12.4183 0 8ZM8.05467 11.6593L12.618 5.46667C12.7723 5.27572 12.8091 5.01545 12.7139 4.78918C12.6187 4.56291 12.4069 4.40726 12.1625 4.38403C11.9182 4.36079 11.6808 4.47373 11.5447 4.678L7.39333 10.312L4.676 8.138C4.38844 7.90788 3.96879 7.95444 3.73867 8.242C3.50855 8.52956 3.55511 8.94921 3.84267 9.17933L7.10133 11.7847C7.24379 11.896 7.42501 11.9455 7.60428 11.9219C7.78355 11.8983 7.94584 11.8037 8.05467 11.6593Z" fill="#1f1f1f"></path></svg>
                <div>
                  
                 <b></b> Interfone<br>                </div>
              </div>

              
                <div class="feature-wrap">
                  <svg class="filter-icon" width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="https://www.w3.org/2000/svg">
                  <path fill-rule="evenodd" clip-rule="evenodd" d="M0 8C0 3.58172 3.58172 0 8 0C12.4161 0.00514317 15.9949 3.58385 16 8C16 12.4183 12.4183 16 8 16C3.58172 16 0 12.4183 0 8ZM8.05467 11.6593L12.618 5.46667C12.7723 5.27572 12.8091 5.01545 12.7139 4.78918C12.6187 4.56291 12.4069 4.40726 12.1625 4.38403C11.9182 4.36079 11.6808 4.47373 11.5447 4.678L7.39333 10.312L4.676 8.138C4.38844 7.90788 3.96879 7.95444 3.73867 8.242C3.50855 8.52956 3.55511 8.94921 3.84267 9.17933L7.10133 11.7847C7.24379 11.896 7.42501 11.9455 7.60428 11.9219C7.78355 11.8983 7.94584 11.8037 8.05467 11.6593Z" fill="#1f1f1f"></path></svg>
                <div>
                  
                 <b></b> Portão<br>                </div>
              </div>

              
                <div class="feature-wrap">
                  <svg class="filter-icon" width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="https://www.w3.org/2000/svg">
                  <path fill-rule="evenodd" clip-rule="evenodd" d="M0 8C0 3.58172 3.58172 0 8 0C12.4161 0.00514317 15.9949 3.58385 16 8C16 12.4183 12.4183 16 8 16C3.58172 16 0 12.4183 0 8ZM8.05467 11.6593L12.618 5.46667C12.7723 5.27572 12.8091 5.01545 12.7139 4.78918C12.6187 4.56291 12.4069 4.40726 12.1625 4.38403C11.9182 4.36079 11.6808 4.47373 11.5447 4.678L7.39333 10.312L4.676 8.138C4.38844 7.90788 3.96879 7.95444 3.73867 8.242C3.50855 8.52956 3.55511 8.94921 3.84267 9.17933L7.10133 11.7847C7.24379 11.896 7.42501 11.9455 7.60428 11.9219C7.78355 11.8983 7.94584 11.8037 8.05467 11.6593Z" fill="#1f1f1f"></path></svg>
                <div>
                  
                 <b></b> Porteiro 24h<br>                </div>
              </div>

              
                <div class="feature-wrap">
                  <svg class="filter-icon" width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="https://www.w3.org/2000/svg">
                  <path fill-rule="evenodd" clip-rule="evenodd" d="M0 8C0 3.58172 3.58172 0 8 0C12.4161 0.00514317 15.9949 3.58385 16 8C16 12.4183 12.4183 16 8 16C3.58172 16 0 12.4183 0 8ZM8.05467 11.6593L12.618 5.46667C12.7723 5.27572 12.8091 5.01545 12.7139 4.78918C12.6187 4.56291 12.4069 4.40726 12.1625 4.38403C11.9182 4.36079 11.6808 4.47373 11.5447 4.678L7.39333 10.312L4.676 8.138C4.38844 7.90788 3.96879 7.95444 3.73867 8.242C3.50855 8.52956 3.55511 8.94921 3.84267 9.17933L7.10133 11.7847C7.24379 11.896 7.42501 11.9455 7.60428 11.9219C7.78355 11.8983 7.94584 11.8037 8.05467 11.6593Z" fill="#1f1f1f"></path></svg>
                <div>
                  
                 <b></b> Salão de festa(s)<br>                </div>
              </div>

              
                <div class="feature-wrap">
                  <svg class="filter-icon" width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="https://www.w3.org/2000/svg">
                  <path fill-rule="evenodd" clip-rule="evenodd" d="M0 8C0 3.58172 3.58172 0 8 0C12.4161 0.00514317 15.9949 3.58385 16 8C16 12.4183 12.4183 16 8 16C3.58172 16 0 12.4183 0 8ZM8.05467 11.6593L12.618 5.46667C12.7723 5.27572 12.8091 5.01545 12.7139 4.78918C12.6187 4.56291 12.4069 4.40726 12.1625 4.38403C11.9182 4.36079 11.6808 4.47373 11.5447 4.678L7.39333 10.312L4.676 8.138C4.38844 7.90788 3.96879 7.95444 3.73867 8.242C3.50855 8.52956 3.55511 8.94921 3.84267 9.17933L7.10133 11.7847C7.24379 11.896 7.42501 11.9455 7.60428 11.9219C7.78355 11.8983 7.94584 11.8037 8.05467 11.6593Z" fill="#1f1f1f"></path></svg>
                <div>
                  
                 <b></b> Espaço Gourmet<br>                </div>
              </div>

              
                <div class="feature-wrap">
                  <svg class="filter-icon" width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="https://www.w3.org/2000/svg">
                  <path fill-rule="evenodd" clip-rule="evenodd" d="M0 8C0 3.58172 3.58172 0 8 0C12.4161 0.00514317 15.9949 3.58385 16 8C16 12.4183 12.4183 16 8 16C3.58172 16 0 12.4183 0 8ZM8.05467 11.6593L12.618 5.46667C12.7723 5.27572 12.8091 5.01545 12.7139 4.78918C12.6187 4.56291 12.4069 4.40726 12.1625 4.38403C11.9182 4.36079 11.6808 4.47373 11.5447 4.678L7.39333 10.312L4.676 8.138C4.38844 7.90788 3.96879 7.95444 3.73867 8.242C3.50855 8.52956 3.55511 8.94921 3.84267 9.17933L7.10133 11.7847C7.24379 11.896 7.42501 11.9455 7.60428 11.9219C7.78355 11.8983 7.94584 11.8037 8.05467 11.6593Z" fill="#1f1f1f"></path></svg>
                <div>
                  
                 <b></b> Portaria Online<br>                </div>
              </div>

              
            </div>
          </div>
        </div>
        

                                <div class="white-block"> <div class="title-block"> <h3 class="heading-12">Dimensões</h3> </div> <div class="content-wrapper"> <div class="w-layout-grid feature-grid">
                  
                <div class="feature-wrap">
                  <svg class="filter-icon" width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="https://www.w3.org/2000/svg">
                  <path fill-rule="evenodd" clip-rule="evenodd" d="M0 8C0 3.58172 3.58172 0 8 0C12.4161 0.00514317 15.9949 3.58385 16 8C16 12.4183 12.4183 16 8 16C3.58172 16 0 12.4183 0 8ZM8.05467 11.6593L12.618 5.46667C12.7723 5.27572 12.8091 5.01545 12.7139 4.78918C12.6187 4.56291 12.4069 4.40726 12.1625 4.38403C11.9182 4.36079 11.6808 4.47373 11.5447 4.678L7.39333 10.312L4.676 8.138C4.38844 7.90788 3.96879 7.95444 3.73867 8.242C3.50855 8.52956 3.55511 8.94921 3.84267 9.17933L7.10133 11.7847C7.24379 11.896 7.42501 11.9455 7.60428 11.9219C7.78355 11.8983 7.94584 11.8037 8.05467 11.6593Z" fill="#1f1f1f"></path></svg>
                <div>
                  
                 <b>300,00m²</b> (m²) Área Total<br>                </div>
              </div>

              
                <div class="feature-wrap">
                  <svg class="filter-icon" width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="https://www.w3.org/2000/svg">
                  <path fill-rule="evenodd" clip-rule="evenodd" d="M0 8C0 3.58172 3.58172 0 8 0C12.4161 0.00514317 15.9949 3.58385 16 8C16 12.4183 12.4183 16 8 16C3.58172 16 0 12.4183 0 8ZM8.05467 11.6593L12.618 5.46667C12.7723 5.27572 12.8091 5.01545 12.7139 4.78918C12.6187 4.56291 12.4069 4.40726 12.1625 4.38403C11.9182 4.36079 11.6808 4.47373 11.5447 4.678L7.39333 10.312L4.676 8.138C4.38844 7.90788 3.96879 7.95444 3.73867 8.242C3.50855 8.52956 3.55511 8.94921 3.84267 9.17933L7.10133 11.7847C7.24379 11.896 7.42501 11.9455 7.60428 11.9219C7.78355 11.8983 7.94584 11.8037 8.05467 11.6593Z" fill="#1f1f1f"></path></svg>
                <div>
                  
                 <b>300,00m²</b> (m²) Área Construída<br>                </div>
              </div>

              
                <div class="feature-wrap">
                  <svg class="filter-icon" width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="https://www.w3.org/2000/svg">
                  <path fill-rule="evenodd" clip-rule="evenodd" d="M0 8C0 3.58172 3.58172 0 8 0C12.4161 0.00514317 15.9949 3.58385 16 8C16 12.4183 12.4183 16 8 16C3.58172 16 0 12.4183 0 8ZM8.05467 11.6593L12.618 5.46667C12.7723 5.27572 12.8091 5.01545 12.7139 4.78918C12.6187 4.56291 12.4069 4.40726 12.1625 4.38403C11.9182 4.36079 11.6808 4.47373 11.5447 4.678L7.39333 10.312L4.676 8.138C4.38844 7.90788 3.96879 7.95444 3.73867 8.242C3.50855 8.52956 3.55511 8.94921 3.84267 9.17933L7.10133 11.7847C7.24379 11.896 7.42501 11.9455 7.60428 11.9219C7.78355 11.8983 7.94584 11.8037 8.05467 11.6593Z" fill="#1f1f1f"></path></svg>
                <div>
                  
                 <b>215,00m²</b> (m²) Área Privativa<br>                </div>
              </div>

              
                <div class="feature-wrap">
                  <svg class="filter-icon" width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="https://www.w3.org/2000/svg">
                  <path fill-rule="evenodd" clip-rule="evenodd" d="M0 8C0 3.58172 3.58172 0 8 0C12.4161 0.00514317 15.9949 3.58385 16 8C16 12.4183 12.4183 16 8 16C3.58172 16 0 12.4183 0 8ZM8.05467 11.6593L12.618 5.46667C12.7723 5.27572 12.8091 5.01545 12.7139 4.78918C12.6187 4.56291 12.4069 4.40726 12.1625 4.38403C11.9182 4.36079 11.6808 4.47373 11.5447 4.678L7.39333 10.312L4.676 8.138C4.38844 7.90788 3.96879 7.95444 3.73867 8.242C3.50855 8.52956 3.55511 8.94921 3.84267 9.17933L7.10133 11.7847C7.24379 11.896 7.42501 11.9455 7.60428 11.9219C7.78355 11.8983 7.94584 11.8037 8.05467 11.6593Z" fill="#1f1f1f"></path></svg>
                <div>
                  
                 <b>12,00m²</b> (m) Frente<br>                </div>
              </div>

              
                <div class="feature-wrap">
                  <svg class="filter-icon" width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="https://www.w3.org/2000/svg">
                  <path fill-rule="evenodd" clip-rule="evenodd" d="M0 8C0 3.58172 3.58172 0 8 0C12.4161 0.00514317 15.9949 3.58385 16 8C16 12.4183 12.4183 16 8 16C3.58172 16 0 12.4183 0 8ZM8.05467 11.6593L12.618 5.46667C12.7723 5.27572 12.8091 5.01545 12.7139 4.78918C12.6187 4.56291 12.4069 4.40726 12.1625 4.38403C11.9182 4.36079 11.6808 4.47373 11.5447 4.678L7.39333 10.312L4.676 8.138C4.38844 7.90788 3.96879 7.95444 3.73867 8.242C3.50855 8.52956 3.55511 8.94921 3.84267 9.17933L7.10133 11.7847C7.24379 11.896 7.42501 11.9455 7.60428 11.9219C7.78355 11.8983 7.94584 11.8037 8.05467 11.6593Z" fill="#1f1f1f"></path></svg>
                <div>
                  
                 <b>12,00m²</b> (m) Fundos<br>                </div>
              </div>

              
                <div class="feature-wrap">
                  <svg class="filter-icon" width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="https://www.w3.org/2000/svg">
                  <path fill-rule="evenodd" clip-rule="evenodd" d="M0 8C0 3.58172 3.58172 0 8 0C12.4161 0.00514317 15.9949 3.58385 16 8C16 12.4183 12.4183 16 8 16C3.58172 16 0 12.4183 0 8ZM8.05467 11.6593L12.618 5.46667C12.7723 5.27572 12.8091 5.01545 12.7139 4.78918C12.6187 4.56291 12.4069 4.40726 12.1625 4.38403C11.9182 4.36079 11.6808 4.47373 11.5447 4.678L7.39333 10.312L4.676 8.138C4.38844 7.90788 3.96879 7.95444 3.73867 8.242C3.50855 8.52956 3.55511 8.94921 3.84267 9.17933L7.10133 11.7847C7.24379 11.896 7.42501 11.9455 7.60428 11.9219C7.78355 11.8983 7.94584 11.8037 8.05467 11.6593Z" fill="#1f1f1f"></path></svg>
                <div>
                  
                 <b>25,00m²</b> (m) Lateral Direita<br>                </div>
              </div>

              
                <div class="feature-wrap">
                  <svg class="filter-icon" width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="https://www.w3.org/2000/svg">
                  <path fill-rule="evenodd" clip-rule="evenodd" d="M0 8C0 3.58172 3.58172 0 8 0C12.4161 0.00514317 15.9949 3.58385 16 8C16 12.4183 12.4183 16 8 16C3.58172 16 0 12.4183 0 8ZM8.05467 11.6593L12.618 5.46667C12.7723 5.27572 12.8091 5.01545 12.7139 4.78918C12.6187 4.56291 12.4069 4.40726 12.1625 4.38403C11.9182 4.36079 11.6808 4.47373 11.5447 4.678L7.39333 10.312L4.676 8.138C4.38844 7.90788 3.96879 7.95444 3.73867 8.242C3.50855 8.52956 3.55511 8.94921 3.84267 9.17933L7.10133 11.7847C7.24379 11.896 7.42501 11.9455 7.60428 11.9219C7.78355 11.8983 7.94584 11.8037 8.05467 11.6593Z" fill="#1f1f1f"></path></svg>
                <div>
                  
                 <b>25,00m²</b> (m) Lateral Esquerda<br>                </div>
              </div>

              
            </div>
          </div>
        </div>
        


          

          <div class="white-block last">
            <div class="title-block">
              <h3 class="heading-12">Localização</h3>
            </div>
           <div class="content-wrapper">
              
                            <div class="w-embed w-iframe"><iframe src="https://sitedeimobiliarias.websiteseguro.com/googlemaps/si9sistemas/mapgeolocal/mapabeto.php?lat=-29.7209675&amp;lng=-53.7949012" name="maps" width="100%" height="300" scrolling="No" frameborder="0" id="maps"></iframe></div>
              

            </div>
          </div>


        </div>
        <div>
          <div class="div-block-2">
            <a href="https://api.whatsapp.com/send?l=pt_br&amp;phone=555532906256&amp;text=Mensagem%20do%20site:%20Desejo%20mais%20detalhes%20- https://www.marcadaterraagro.com.br/imovel/venda/casa/santa-maria-rs/tomazetti/casa-de-alto-padrao-no-condominio-fechado-royal-park--morar-bem/585797" target="_blank" class="avatar-base-2 w-inline-block">
              <div class="avatar-wrap"><img src="https://www.marcadaterraagro.com.br/images/whatsappdetalhes.png" loading="lazy" alt=""></div>
              <div>
                <div class="agent-name-2">Chamar no WhatsApp Agora!</div>
                <div class="agent-link">Clique aqui</div>
              </div>
            </a>
            <div class="w-form">

                <form id="email-form" name="email-form" method="post" action="https://www.marcadaterraagro.com.br/email-detalhes.php" data-name="Email Form">
                  

                    <input type="text" data-name="urlimovel" id="urlimovel" name="urlimovel" value="https://www.marcadaterraagro.com.br/imovel/venda/casa/santa-maria-rs/tomazetti/casa-de-alto-padrao-no-condominio-fechado-royal-park--morar-bem/585797" style="display: none;">


                <input type="text" class="text-field w-input" data-name="nome" id="nome" maxlength="256" placeholder="Nome Completo" name="nome" required="">

                <input pattern="[0-9]+" type="tel" class="text-field w-input" name="telefone" placeholder="Telefone  / Whatsapp" id="telefone" required="">

                <input type="email" class="text-field w-input" maxlength="256" name="email" data-name="Email" placeholder="Email" id="email" required="">

                <textarea maxlength="5000" id="obs" name="obs" data-name="Message" required="" class="text-field-large w-input">Olá, estou interessado neste imóvel para Venda de Ref.: 357, e gostaria de mais informações.</textarea>
                    <input class="button-submit w-button" type="submit" value="Enviar">
              </form>
            </div>
            <div style=" float: right;">
             <a href="#" class="property-text-light" style="color: #333; text-decoration: none; margin-bottom: 10px;" onclick="window.print()">Imprimir imóvel 
             <img src="https://www.marcadaterraagro.com.br/images/printer.png" style="width: 20px;"></a>
             </div>

            <div class="property-text-light" style="color: #333;">Compartilhe

           <div class="div-botoes" id="redes">
                    <!-- AddToAny BEGIN -->
<div class="a2a_kit a2a_kit_size_32 a2a_default_style" style="line-height: 32px;">
<a class="a2a_dd" href="https://www.addtoany.com/share#url=https%3A%2F%2Fwww.marcadaterraagro.com.br%2Fimovel%2Fvenda%2Fcasa%2Fsanta-maria-rs%2Ftomazetti%2Fcasa-de-alto-padrao-no-condominio-fechado-royal-park--morar-bem%2F585797&amp;title=Casa%20de%20alto%20padr%C3%A3o%20no%20condom%C3%ADnio%20fechado%20Royal%20Park%2C%20morar%20bem%20-%20Marca%20da%20Terra%20Agroneg%C3%B3cios"><span class="a2a_svg a2a_s__default a2a_s_a2a" style="background-color: rgb(1, 102, 255);"><svg focusable="false" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 32 32"><g fill="#FFF"><path d="M14 7h4v18h-4z"></path><path d="M7 14h18v4H7z"></path></g></svg></span><span class="a2a_label a2a_localize" data-a2a-localize="inner,Share">Compartilhe</span></a>
<a class="a2a_button_whatsapp" target="_blank" rel="nofollow noopener" href="/#whatsapp"><span class="a2a_svg a2a_s__default a2a_s_whatsapp" style="background-color: rgb(18, 175, 10);"><svg focusable="false" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 32 32"><path fill-rule="evenodd" clip-rule="evenodd" fill="#FFF" d="M16.21 4.41C9.973 4.41 4.917 9.465 4.917 15.7c0 2.134.592 4.13 1.62 5.832L4.5 27.59l6.25-2.002a11.241 11.241 0 0 0 5.46 1.404c6.234 0 11.29-5.055 11.29-11.29 0-6.237-5.056-11.292-11.29-11.292zm0 20.69c-1.91 0-3.69-.57-5.173-1.553l-3.61 1.156 1.173-3.49a9.345 9.345 0 0 1-1.79-5.512c0-5.18 4.217-9.4 9.4-9.4 5.183 0 9.397 4.22 9.397 9.4 0 5.188-4.214 9.4-9.398 9.4zm5.293-6.832c-.284-.155-1.673-.906-1.934-1.012-.265-.106-.455-.16-.658.12s-.78.91-.954 1.096c-.176.186-.345.203-.628.048-.282-.154-1.2-.494-2.264-1.517-.83-.795-1.373-1.76-1.53-2.055-.158-.295 0-.445.15-.584.134-.124.3-.326.45-.488.15-.163.203-.28.306-.47.104-.19.06-.36-.005-.506-.066-.147-.59-1.587-.81-2.173-.218-.586-.46-.498-.63-.505-.168-.007-.358-.038-.55-.045-.19-.007-.51.054-.78.332-.277.274-1.05.943-1.1 2.362-.055 1.418.926 2.826 1.064 3.023.137.2 1.874 3.272 4.76 4.537 2.888 1.264 2.9.878 3.43.85.53-.027 1.734-.633 2-1.297.266-.664.287-1.24.22-1.363-.07-.123-.26-.203-.54-.357z"></path></svg></span><span class="a2a_label">WhatsApp</span></a>
<a class="a2a_button_twitter" target="_blank" rel="nofollow noopener" href="/#twitter"><span class="a2a_svg a2a_s__default a2a_s_twitter" style="background-color: rgb(29, 155, 240);"><svg focusable="false" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 32 32"><path fill="#FFF" d="M28 8.557a9.913 9.913 0 0 1-2.828.775 4.93 4.93 0 0 0 2.166-2.725 9.738 9.738 0 0 1-3.13 1.194 4.92 4.92 0 0 0-3.593-1.55 4.924 4.924 0 0 0-4.794 6.049c-4.09-.21-7.72-2.17-10.15-5.15a4.942 4.942 0 0 0-.665 2.477c0 1.71.87 3.214 2.19 4.1a4.968 4.968 0 0 1-2.23-.616v.06c0 2.39 1.7 4.38 3.952 4.83-.414.115-.85.174-1.297.174-.318 0-.626-.03-.928-.086a4.935 4.935 0 0 0 4.6 3.42 9.893 9.893 0 0 1-6.114 2.107c-.398 0-.79-.023-1.175-.068a13.953 13.953 0 0 0 7.55 2.213c9.056 0 14.01-7.507 14.01-14.013 0-.213-.005-.426-.015-.637.96-.695 1.795-1.56 2.455-2.55z"></path></svg></span><span class="a2a_label">Twitter</span></a>
<a class="a2a_button_facebook" target="_blank" rel="nofollow noopener" href="/#facebook"><span class="a2a_svg a2a_s__default a2a_s_facebook" style="background-color: rgb(8, 102, 255);"><svg focusable="false" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 32 32"><path fill="#FFF" d="M17.78 27.5V17.008h3.522l.527-4.09h-4.05v-2.61c0-1.182.33-1.99 2.023-1.99h2.166V4.66c-.375-.05-1.66-.16-3.155-.16-3.123 0-5.26 1.905-5.26 5.405v3.016h-3.53v4.09h3.53V27.5h4.223z"></path></svg></span><span class="a2a_label">Facebook</span></a>
<a class="a2a_button_telegram" target="_blank" rel="nofollow noopener" href="/#telegram"><span class="a2a_svg a2a_s__default a2a_s_telegram" style="background-color: rgb(44, 165, 224);"><svg focusable="false" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 32 32"><path fill="#FFF" d="M25.515 6.896 6.027 14.41c-1.33.534-1.322 1.276-.243 1.606l5 1.56 1.72 5.66c.226.625.115.873.77.873.506 0 .73-.235 1.012-.51l2.43-2.363 5.056 3.734c.93.514 1.602.25 1.834-.863l3.32-15.638c.338-1.363-.52-1.98-1.41-1.577z"></path></svg></span><span class="a2a_label">Telegram</span></a>
<a class="a2a_button_email" target="_blank" rel="nofollow noopener" href="/#email"><span class="a2a_svg a2a_s__default a2a_s_email" style="background-color: rgb(136, 137, 144);"><svg focusable="false" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 32 32"><path fill="#FFF" d="M26 21.25v-9s-9.1 6.35-9.984 6.68C15.144 18.616 6 12.25 6 12.25v9c0 1.25.266 1.5 1.5 1.5h17c1.266 0 1.5-.22 1.5-1.5zm-.015-10.765c0-.91-.265-1.235-1.485-1.235h-17c-1.255 0-1.5.39-1.5 1.3l.015.14s9.035 6.22 10 6.56c1.02-.395 9.985-6.7 9.985-6.7l-.015-.065z"></path></svg></span><span class="a2a_label">Email</span></a>
<a class="a2a_button_pinterest" target="_blank" rel="nofollow noopener" href="/#pinterest"><span class="a2a_svg a2a_s__default a2a_s_pinterest" style="background-color: rgb(189, 8, 28);"><svg focusable="false" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 32 32"><path fill="#FFF" d="M16.539 4.5c-6.277 0-9.442 4.5-9.442 8.253 0 2.272.86 4.293 2.705 5.046.303.125.574.005.662-.33.061-.231.205-.816.27-1.06.088-.331.053-.447-.191-.736-.532-.627-.873-1.439-.873-2.591 0-3.338 2.498-6.327 6.505-6.327 3.548 0 5.497 2.168 5.497 5.062 0 3.81-1.686 7.025-4.188 7.025-1.382 0-2.416-1.142-2.085-2.545.397-1.674 1.166-3.48 1.166-4.689 0-1.081-.581-1.983-1.782-1.983-1.413 0-2.548 1.462-2.548 3.419 0 1.247.421 2.091.421 2.091l-1.699 7.199c-.505 2.137-.076 4.755-.039 5.019.021.158.223.196.314.077.13-.17 1.813-2.247 2.384-4.324.162-.587.929-3.631.929-3.631.46.876 1.801 1.646 3.227 1.646 4.247 0 7.128-3.871 7.128-9.053.003-3.918-3.317-7.568-8.361-7.568z"></path></svg></span><span class="a2a_label">Pinterest</span></a>
<a class="a2a_button_facebook_messenger" target="_blank" rel="nofollow noopener" href="/#facebook_messenger"><span class="a2a_svg a2a_s__default a2a_s_facebook_messenger" style="background-color: rgb(0, 132, 255);"><svg focusable="false" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 32 32"><path fill="#FFF" d="M16 5C9.986 5 5.11 9.56 5.11 15.182c0 3.2 1.58 6.054 4.046 7.92V27l3.716-2.06c.99.276 2.04.425 3.128.425 6.014 0 10.89-4.56 10.89-10.183S22.013 5 16 5zm1.147 13.655L14.33 15.73l-5.423 3 5.946-6.31 2.816 2.925 5.42-3-5.946 6.31z"></path></svg></span><span class="a2a_label">Messenger</span></a>
<div style="clear: both;"></div></div>
<script async="" src="https://static.addtoany.com/menu/page.js"></script>
<!-- AddToAny END -->

                </div>
                <script type="text/javascript" src="https://s7.addthis.com/js/300/addthis_widget.js#pubid=ra-5c51a2abdc3d1b17"></script>
          </div>


          </div>
        </div>
      </div>
      <div class="div-block-93">
        <div class="title-wrap-2 imoveis">
          <div class="title-line"></div>
          <h2 class="heading-7 othrt">Imóveis similares</h2>
        </div>
        <div class="div-block-94">


             

           <a href="https://www.marcadaterraagro.com.br/imovel/venda/apartamento/santa-maria-rs/centro/apartamento-a-venda--centro--santa-maria---rs/586391" class="div-block-11 w-inline-block">
        <div class="property-image-wrap"><img src="https://si9dados.com.br/si9-fotos/marcadaterra/16977435272761697743527035e13494d9-93a6-4764-9b8d-e3b693da7d98.jpeg" alt="Apartamento à venda, Centro, SANTA MARIA - RS" class="property-image">
        <div class="text-block-65">Venda</div>        </div>
        <div class="div-block-12">
          <div class="div-block-13">
            <div class="heading-4">Apartamento à venda, Centro, SANTA MARIA - RS</div>
            <div class="text-block-15">Centro, SANTA MARIA - RS</div>
            <div class="text-block-14">Apartamento  a venda: 150.000,00 "apartamento no centro da cidade - Ótima oportu...</div>
            <div class="div-block-14">
              <div class="text-block-11"> R$ 150.000,00</div>
            </div>
          </div>
          </div>

          <div class="w-layout-grid room-feature-grid">





                    
                     
                                          <div class="feature">
                    <div style="font-size: 12px; font-family: Circularstd, sans-serif">1</div>
                    <svg class="feature-icon" width="21" height="20" viewBox="0 0 17 16" fill="none" xmlns="https://www.w3.org/2000/svg">
                    <path fill-rule="evenodd" clip-rule="evenodd" d="M15.3333 9.33335C15.5178 9.33468 15.6935 9.41183 15.8193 9.54668C15.9455 9.67886 16.011 9.85761 16 10.04C15.7997 13.3874 13.0267 15.9997 9.67333 16H6.32666C2.97324 15.9997 0.200326 13.3874 -4.91715e-06 10.04C-0.00878807 9.85806 0.0560946 9.68023 0.179995 9.54668C0.304916 9.41018 0.481628 9.33272 0.666662 9.33335H3.07866C3.22565 9.33473 3.3562 9.23967 3.4 9.09935C3.5741 8.54572 4.08631 8.1683 4.66666 8.16601H8.00333C8.58368 8.1683 9.09589 8.54572 9.26999 9.09935C9.31343 9.23849 9.44223 9.33327 9.588 9.33335H13.166C13.3501 9.33335 13.4993 9.18411 13.4993 9.00001V2.00001C13.5001 1.73655 13.3456 1.49736 13.1051 1.38968C12.8647 1.282 12.5834 1.32602 12.3873 1.50201L12.114 1.77535C12.0251 1.86493 11.9943 1.99706 12.0347 2.11668C12.2671 2.80327 12.0907 3.56229 11.5793 4.07601L11.446 4.21268C11.1857 4.47294 10.7637 4.47294 10.5033 4.21268L8.74 2.44868C8.47974 2.18835 8.47974 1.76635 8.74 1.50601L8.87666 1.36935C9.39648 0.872756 10.147 0.701707 10.8307 0.924014C10.9494 0.96174 11.0792 0.930112 11.1673 0.842014L11.476 0.533348C12.0593 -0.00563735 12.9062 -0.148438 13.634 0.169491C14.3617 0.487419 14.8324 1.20583 14.8333 2.00001V9.00001C14.8333 9.18411 14.9826 9.33335 15.1667 9.33335H15.3333ZM7.66666 13.5C7.85076 13.5 8 13.3508 8 13.1667V9.83335C8 9.64925 7.85076 9.50001 7.66666 9.50001H5C4.8159 9.50001 4.66666 9.64925 4.66666 9.83335V13.1667C4.66666 13.3508 4.8159 13.5 5 13.5H7.66666Z" fill="black"></path>
                    <path d="M6 4.05856C6.09626 4.0594 6.19155 4.03939 6.27934 3.99989L7.49 3.44123C7.70663 3.34179 7.85374 3.13434 7.87594 2.89702C7.89813 2.6597 7.79203 2.42856 7.5976 2.29068C7.40318 2.1528 7.14996 2.12912 6.93334 2.22856L5.72067 2.78656C5.43638 2.91774 5.28168 3.22908 5.34883 3.53489C5.41599 3.8407 5.68691 4.05857 6 4.05856Z" fill="black"></path>
                    <path d="M9.41467 7.67273C9.75322 7.81715 10.1448 7.65988 10.2893 7.3214L10.8133 6.09473C10.9485 5.75826 10.7899 5.37548 10.4564 5.23312C10.1229 5.09077 9.73684 5.24106 9.58734 5.5714L9.06667 6.80007C8.92318 7.13716 9.07859 7.52688 9.41467 7.67273Z" fill="black"></path>
                    <path d="M6.99064 6.05074C7.24968 6.31229 7.67168 6.31438 7.9333 6.05541L8.8813 5.11807C9.13584 4.85799 9.13478 4.44183 8.87891 4.18304C8.62304 3.92426 8.20692 3.91849 7.94397 4.17007L6.99597 5.10807C6.73424 5.36693 6.73185 5.78894 6.99064 6.05074Z" fill="black"></path>
                    </svg>

                      <span class="feature-escrita"> Banheiro(s)</span>
                    </div>
                    
                   
                                        <div class="feature">

                       <div style="font-size: 12px; font-family: Circularstd, sans-serif">83,00</div>
        <svg class="feature-icon" width="20" height="20" version="1.1" id="Capa_1" xmlns="https://www.w3.org/2000/svg" xmlns:xlink="https://www.w3.org/1999/xlink" x="0px" y="0px" viewBox="0 0 477.871 477.871" style="enable-background:new 0 0 477.871 477.871;" xml:space="preserve">
        <path d="M457.957,347.779H130.09V19.912C130.09,8.915,121.178,0,110.182,0H19.91C8.912,0,0,8.915,0,19.912v19.912h29.195
          c4.404,0,7.967,3.561,7.967,7.964c0,4.403-3.563,7.964-7.967,7.964H0v41.417h29.195c4.404,0,7.967,3.563,7.967,7.964
          c0,4.403-3.563,7.964-7.967,7.964H0v41.418h29.195c4.404,0,7.967,3.562,7.967,7.964c0,4.401-3.563,7.965-7.967,7.965H0v41.41h29.195
          c4.404,0,7.967,3.562,7.967,7.964c0,4.401-3.563,7.964-7.967,7.964H0V269.2h29.195c4.404,0,7.967,3.561,7.967,7.964
          c0,4.403-3.563,7.964-7.967,7.964H0v41.417h29.195c4.404,0,7.967,3.563,7.967,7.966c0,4.401-3.563,7.964-7.967,7.964H0v5.303
          v110.183c0,10.997,8.912,19.91,19.91,19.91h110.18h5.307v-29.198c0-4.401,3.563-7.964,7.961-7.964c4.404,0,7.967,3.563,7.967,7.964
          v29.198h41.409v-29.198c0-4.401,3.564-7.964,7.962-7.964c4.402,0,7.967,3.563,7.967,7.964v29.198h41.424v-29.198
          c0-4.401,3.564-7.964,7.967-7.964c4.402,0,7.963,3.563,7.963,7.964v29.198h41.409v-29.198c0-4.401,3.562-7.964,7.967-7.964
          c4.402,0,7.961,3.563,7.961,7.964v29.198h41.429v-29.198c0-4.401,3.559-7.964,7.961-7.964c4.404,0,7.967,3.563,7.967,7.964v29.198
          h41.409v-29.198c0-4.401,3.56-7.964,7.962-7.964c4.402,0,7.967,3.563,7.967,7.964v29.198h19.91c10.996,0,19.914-8.913,19.914-19.903
          v-90.284C477.871,356.694,468.953,347.779,457.957,347.779z M65.549,426.096c-10.547,0-19.088-8.548-19.088-19.087
          c0-10.54,8.541-19.088,19.088-19.088c10.549,0,19.088,8.549,19.088,19.088C84.637,417.547,76.098,426.096,65.549,426.096z"></path>

        </svg>




                     <span class="feature-escrita"> Privativa</span> 
                    </div>
                    

                </div>
      </a>
      
       

           <a href="https://www.marcadaterraagro.com.br/imovel/venda/apartamento/santa-maria-rs/nossa-senhora-de-fatima/apartamento-a-venda--nossa-senhora-de-fatima--santa-maria---rs/414656" class="div-block-11 w-inline-block">
        <div class="property-image-wrap"><img src="https://si9dados.com.br/si9-fotos/marcadaterra/16498797558201649879755685e210af1b-d2e6-4d36-9996-f0e4e1dd790f.jpeg" alt="Apartamento à venda, Nossa Senhora de Fátima, SANTA MARIA - RS" class="property-image">
        <div class="text-block-65">Venda</div>        </div>
        <div class="div-block-12">
          <div class="div-block-13">
            <div class="heading-4">Apartamento à venda, Nossa Senhora de Fátima, SANTA MARIA - RS</div>
            <div class="text-block-15">Nossa Senhora de Fátima, SANTA MARIA - RS</div>
            <div class="text-block-14">Você vai adorar este apartamento, localizado em andar alto e com vista espetacul...</div>
            <div class="div-block-14">
              <div class="text-block-11"> R$ 480.000,00</div>
            </div>
          </div>
          </div>

          <div class="w-layout-grid room-feature-grid">





                    
                     
                                          <div class="feature">
                    <div style="font-size: 12px; font-family: Circularstd, sans-serif">2</div>
                    <svg class="feature-icon" width="21" height="20" viewBox="0 0 17 16" fill="none" xmlns="https://www.w3.org/2000/svg">
                    <path fill-rule="evenodd" clip-rule="evenodd" d="M15.3333 9.33335C15.5178 9.33468 15.6935 9.41183 15.8193 9.54668C15.9455 9.67886 16.011 9.85761 16 10.04C15.7997 13.3874 13.0267 15.9997 9.67333 16H6.32666C2.97324 15.9997 0.200326 13.3874 -4.91715e-06 10.04C-0.00878807 9.85806 0.0560946 9.68023 0.179995 9.54668C0.304916 9.41018 0.481628 9.33272 0.666662 9.33335H3.07866C3.22565 9.33473 3.3562 9.23967 3.4 9.09935C3.5741 8.54572 4.08631 8.1683 4.66666 8.16601H8.00333C8.58368 8.1683 9.09589 8.54572 9.26999 9.09935C9.31343 9.23849 9.44223 9.33327 9.588 9.33335H13.166C13.3501 9.33335 13.4993 9.18411 13.4993 9.00001V2.00001C13.5001 1.73655 13.3456 1.49736 13.1051 1.38968C12.8647 1.282 12.5834 1.32602 12.3873 1.50201L12.114 1.77535C12.0251 1.86493 11.9943 1.99706 12.0347 2.11668C12.2671 2.80327 12.0907 3.56229 11.5793 4.07601L11.446 4.21268C11.1857 4.47294 10.7637 4.47294 10.5033 4.21268L8.74 2.44868C8.47974 2.18835 8.47974 1.76635 8.74 1.50601L8.87666 1.36935C9.39648 0.872756 10.147 0.701707 10.8307 0.924014C10.9494 0.96174 11.0792 0.930112 11.1673 0.842014L11.476 0.533348C12.0593 -0.00563735 12.9062 -0.148438 13.634 0.169491C14.3617 0.487419 14.8324 1.20583 14.8333 2.00001V9.00001C14.8333 9.18411 14.9826 9.33335 15.1667 9.33335H15.3333ZM7.66666 13.5C7.85076 13.5 8 13.3508 8 13.1667V9.83335C8 9.64925 7.85076 9.50001 7.66666 9.50001H5C4.8159 9.50001 4.66666 9.64925 4.66666 9.83335V13.1667C4.66666 13.3508 4.8159 13.5 5 13.5H7.66666Z" fill="black"></path>
                    <path d="M6 4.05856C6.09626 4.0594 6.19155 4.03939 6.27934 3.99989L7.49 3.44123C7.70663 3.34179 7.85374 3.13434 7.87594 2.89702C7.89813 2.6597 7.79203 2.42856 7.5976 2.29068C7.40318 2.1528 7.14996 2.12912 6.93334 2.22856L5.72067 2.78656C5.43638 2.91774 5.28168 3.22908 5.34883 3.53489C5.41599 3.8407 5.68691 4.05857 6 4.05856Z" fill="black"></path>
                    <path d="M9.41467 7.67273C9.75322 7.81715 10.1448 7.65988 10.2893 7.3214L10.8133 6.09473C10.9485 5.75826 10.7899 5.37548 10.4564 5.23312C10.1229 5.09077 9.73684 5.24106 9.58734 5.5714L9.06667 6.80007C8.92318 7.13716 9.07859 7.52688 9.41467 7.67273Z" fill="black"></path>
                    <path d="M6.99064 6.05074C7.24968 6.31229 7.67168 6.31438 7.9333 6.05541L8.8813 5.11807C9.13584 4.85799 9.13478 4.44183 8.87891 4.18304C8.62304 3.92426 8.20692 3.91849 7.94397 4.17007L6.99597 5.10807C6.73424 5.36693 6.73185 5.78894 6.99064 6.05074Z" fill="black"></path>
                    </svg>

                      <span class="feature-escrita"> Banheiro(s)</span>
                    </div>
                    
                   
                    

                </div>
      </a>
      
       

           <a href="https://www.marcadaterraagro.com.br/imovel/venda/casa/santa-maria-rs/nossa-senhora-de-fatima/casa-com-5-dormitorios-a-venda--nossa-senhora-de-fatima--santa-maria---rs/575756" class="div-block-11 w-inline-block">
        <div class="property-image-wrap"><img src="https://si9dados.com.br/si9-fotos/marcadaterra/16945370855081694537085227WhatsAppImage2023-09-11at16.19.383.jpeg" alt="Casa com 5 dormitórios à venda, Nossa Senhora de Fátima, SANTA..." class="property-image">
        <div class="text-block-65">Venda</div>        </div>
        <div class="div-block-12">
          <div class="div-block-13">
            <div class="heading-4">Casa com 5 dormitórios à venda, Nossa Senhora de Fátima, SANTA MARIA - RS</div>
            <div class="text-block-15">Nossa Senhora de Fátima, SANTA MARIA - RS</div>
            <div class="text-block-14">Essa casa residencial É incrível!  com uma área construída de 278m² e uma locali...</div>
            <div class="div-block-14">
              <div class="text-block-11"> R$ 720.000,00</div>
            </div>
          </div>
          </div>

          <div class="w-layout-grid room-feature-grid">





                    
                     
                                          <div class="feature">
                    <div style="font-size: 12px; font-family: Circularstd, sans-serif">5</div>
                    <svg class="feature-icon" width="21" height="20" viewBox="0 0 17 16" fill="none" xmlns="https://www.w3.org/2000/svg">
                    <path fill-rule="evenodd" clip-rule="evenodd" d="M15.3333 9.33335C15.5178 9.33468 15.6935 9.41183 15.8193 9.54668C15.9455 9.67886 16.011 9.85761 16 10.04C15.7997 13.3874 13.0267 15.9997 9.67333 16H6.32666C2.97324 15.9997 0.200326 13.3874 -4.91715e-06 10.04C-0.00878807 9.85806 0.0560946 9.68023 0.179995 9.54668C0.304916 9.41018 0.481628 9.33272 0.666662 9.33335H3.07866C3.22565 9.33473 3.3562 9.23967 3.4 9.09935C3.5741 8.54572 4.08631 8.1683 4.66666 8.16601H8.00333C8.58368 8.1683 9.09589 8.54572 9.26999 9.09935C9.31343 9.23849 9.44223 9.33327 9.588 9.33335H13.166C13.3501 9.33335 13.4993 9.18411 13.4993 9.00001V2.00001C13.5001 1.73655 13.3456 1.49736 13.1051 1.38968C12.8647 1.282 12.5834 1.32602 12.3873 1.50201L12.114 1.77535C12.0251 1.86493 11.9943 1.99706 12.0347 2.11668C12.2671 2.80327 12.0907 3.56229 11.5793 4.07601L11.446 4.21268C11.1857 4.47294 10.7637 4.47294 10.5033 4.21268L8.74 2.44868C8.47974 2.18835 8.47974 1.76635 8.74 1.50601L8.87666 1.36935C9.39648 0.872756 10.147 0.701707 10.8307 0.924014C10.9494 0.96174 11.0792 0.930112 11.1673 0.842014L11.476 0.533348C12.0593 -0.00563735 12.9062 -0.148438 13.634 0.169491C14.3617 0.487419 14.8324 1.20583 14.8333 2.00001V9.00001C14.8333 9.18411 14.9826 9.33335 15.1667 9.33335H15.3333ZM7.66666 13.5C7.85076 13.5 8 13.3508 8 13.1667V9.83335C8 9.64925 7.85076 9.50001 7.66666 9.50001H5C4.8159 9.50001 4.66666 9.64925 4.66666 9.83335V13.1667C4.66666 13.3508 4.8159 13.5 5 13.5H7.66666Z" fill="black"></path>
                    <path d="M6 4.05856C6.09626 4.0594 6.19155 4.03939 6.27934 3.99989L7.49 3.44123C7.70663 3.34179 7.85374 3.13434 7.87594 2.89702C7.89813 2.6597 7.79203 2.42856 7.5976 2.29068C7.40318 2.1528 7.14996 2.12912 6.93334 2.22856L5.72067 2.78656C5.43638 2.91774 5.28168 3.22908 5.34883 3.53489C5.41599 3.8407 5.68691 4.05857 6 4.05856Z" fill="black"></path>
                    <path d="M9.41467 7.67273C9.75322 7.81715 10.1448 7.65988 10.2893 7.3214L10.8133 6.09473C10.9485 5.75826 10.7899 5.37548 10.4564 5.23312C10.1229 5.09077 9.73684 5.24106 9.58734 5.5714L9.06667 6.80007C8.92318 7.13716 9.07859 7.52688 9.41467 7.67273Z" fill="black"></path>
                    <path d="M6.99064 6.05074C7.24968 6.31229 7.67168 6.31438 7.9333 6.05541L8.8813 5.11807C9.13584 4.85799 9.13478 4.44183 8.87891 4.18304C8.62304 3.92426 8.20692 3.91849 7.94397 4.17007L6.99597 5.10807C6.73424 5.36693 6.73185 5.78894 6.99064 6.05074Z" fill="black"></path>
                    </svg>

                      <span class="feature-escrita"> Banheiro(s)</span>
                    </div>
                    
                                       <div class="feature">
        <div style="font-size: 12px; font-family: Circularstd, sans-serif">1</div>
        <svg class="feature-icon" width="20" height="20" version="1.1" id="Capa_1" xmlns="https://www.w3.org/2000/svg" xmlns:xlink="https://www.w3.org/1999/xlink" x="0px" y="0px" viewBox="0 0 39.055 39.054" style="enable-background:new 0 0 39.055 39.054;" xml:space="preserve">
        <g>
            <path d="M38.831,14.26c-0.191-0.233-0.476-0.369-0.775-0.369h-3.801c-0.938-2.474-2.16-4.898-3.549-5.813
              c-4.805-3.161-17.55-3.161-22.355,0c-1.39,0.916-2.607,3.343-3.55,5.813H1c-0.302,0-0.586,0.136-0.775,0.369
              c-0.19,0.232-0.266,0.539-0.204,0.834l0.563,2.728c0.096,0.465,0.506,0.797,0.979,0.797h1.126
              c-1.087,1.254-1.614,2.833-1.621,4.413c-0.007,1.952,0.734,3.716,2.089,4.964c0.015,0.013,0.03,0.022,0.044,0.035v3.817
              c0,0.827,0.672,1.5,1.5,1.5h3.506c0.828,0,1.5-0.673,1.5-1.5v-1.534h19.641v1.534c0,0.827,0.672,1.5,1.5,1.5h3.506
              c0.826,0,1.5-0.673,1.5-1.5v-3.742c1.438-1.317,2.125-3.129,2.134-4.938c0.006-1.634-0.545-3.271-1.696-4.551h1.201
              c0.475,0,0.885-0.332,0.979-0.798l0.564-2.727C39.094,14.799,39.021,14.494,38.831,14.26z M9.998,10.583
              c3.83-2.521,15.229-2.521,19.057,0c0.744,0.488,1.701,2.461,2.578,4.877H7.422C8.297,13.045,9.254,11.073,9.998,10.583z
               M5.512,23.408c0-1.63,1.322-2.95,2.951-2.95c1.631,0,2.951,1.32,2.951,2.95s-1.32,2.951-2.951,2.951
              C6.834,26.359,5.512,25.038,5.512,23.408z M30.631,26.359c-1.629,0-2.951-1.321-2.951-2.951s1.322-2.95,2.951-2.95
              c1.631,0,2.951,1.32,2.951,2.95S32.26,26.359,30.631,26.359z"></path>
          </g>
        </svg>


                      <span class="feature-escrita"> Vaga(s)</span>
                    </div>
                    
                                        <div class="feature">

                       <div style="font-size: 12px; font-family: Circularstd, sans-serif">278,00</div>
        <svg class="feature-icon" width="20" height="20" version="1.1" id="Capa_1" xmlns="https://www.w3.org/2000/svg" xmlns:xlink="https://www.w3.org/1999/xlink" x="0px" y="0px" viewBox="0 0 477.871 477.871" style="enable-background:new 0 0 477.871 477.871;" xml:space="preserve">
        <path d="M457.957,347.779H130.09V19.912C130.09,8.915,121.178,0,110.182,0H19.91C8.912,0,0,8.915,0,19.912v19.912h29.195
          c4.404,0,7.967,3.561,7.967,7.964c0,4.403-3.563,7.964-7.967,7.964H0v41.417h29.195c4.404,0,7.967,3.563,7.967,7.964
          c0,4.403-3.563,7.964-7.967,7.964H0v41.418h29.195c4.404,0,7.967,3.562,7.967,7.964c0,4.401-3.563,7.965-7.967,7.965H0v41.41h29.195
          c4.404,0,7.967,3.562,7.967,7.964c0,4.401-3.563,7.964-7.967,7.964H0V269.2h29.195c4.404,0,7.967,3.561,7.967,7.964
          c0,4.403-3.563,7.964-7.967,7.964H0v41.417h29.195c4.404,0,7.967,3.563,7.967,7.966c0,4.401-3.563,7.964-7.967,7.964H0v5.303
          v110.183c0,10.997,8.912,19.91,19.91,19.91h110.18h5.307v-29.198c0-4.401,3.563-7.964,7.961-7.964c4.404,0,7.967,3.563,7.967,7.964
          v29.198h41.409v-29.198c0-4.401,3.564-7.964,7.962-7.964c4.402,0,7.967,3.563,7.967,7.964v29.198h41.424v-29.198
          c0-4.401,3.564-7.964,7.967-7.964c4.402,0,7.963,3.563,7.963,7.964v29.198h41.409v-29.198c0-4.401,3.562-7.964,7.967-7.964
          c4.402,0,7.961,3.563,7.961,7.964v29.198h41.429v-29.198c0-4.401,3.559-7.964,7.961-7.964c4.404,0,7.967,3.563,7.967,7.964v29.198
          h41.409v-29.198c0-4.401,3.56-7.964,7.962-7.964c4.402,0,7.967,3.563,7.967,7.964v29.198h19.91c10.996,0,19.914-8.913,19.914-19.903
          v-90.284C477.871,356.694,468.953,347.779,457.957,347.779z M65.549,426.096c-10.547,0-19.088-8.548-19.088-19.087
          c0-10.54,8.541-19.088,19.088-19.088c10.549,0,19.088,8.549,19.088,19.088C84.637,417.547,76.098,426.096,65.549,426.096z"></path>

        </svg>




                     <span class="feature-escrita"> Privativa</span> 
                    </div>
                    

                </div>
      </a>
      
       

          
        </div>
      </div>
    </div>
  </div>
    </body>
</html>