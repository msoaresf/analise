<?php
require_once './shared/header.php';
?>
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <style>
        label{
             font-size: 120%;
            
            
        }
    </style>
    <body>
        <form method="post" action="">
             <div class="col-md-1"></div>
             <div class="col-md-10">
            <div class="container">
                <?php
                ?> 
                <br><br>
                <h1>Cadastro Imovel</h1>
                <input type="hidden" name="id" value="<?php // echo @(isset($racaObject)? $racaObject->getId():'')  ?>">
                <div class="form-group">
                    <label for="nome">Nome imovel:</label>
                    <input type="text" class="form-control" value="<?php // echo @(isset($racaObject)? $racaObject->getNome():'')   ?>" name="nome" id="nome">
                </div>
                <div class="form-group">
                    <label for="descricao">Preço:</label>
                    <input type="text" class="form-control" id="descricao" value="<?php // echo @(isset($racaObject)? $racaObject->getDescricao():'')   ?>" name="descricao">
                </div> 
                <div class="form-group">
                    <label for="faixaPreco">Banheiros:</label>
                    <input type="text" class="form-control" id="faixaPreco" value="<?php //echo @(isset($racaObject)? $racaObject->getFaixaPreco():'')   ?>" name="faixaPreco">
                </div> 
                <div class="form-group">
                    <label for="faixaPeso">Quartos:</label>
                    <input type="text" class="form-control" id="faixaPeso" value="<?php //echo @(isset($racaObject)? $racaObject->getFaixaPeso():'')   ?>" name="faixaPeso">
                </div> 
                <div class="form-group">
                    <label for="faixaPeso">Quartos:</label>
                    <input type="text" class="form-control" id="faixaPeso" value="<?php //echo @(isset($racaObject)? $racaObject->getFaixaPeso():'')   ?>" name="faixaPeso">
                </div>
                <div class="form-group">
                    <label for="faixaPeso">CEP:</label>
                    <input type="text" class="form-control" id="faixaPeso" value="<?php //echo @(isset($racaObject)? $racaObject->getFaixaPeso():'')   ?>" name="faixaPeso">
                </div>
            </div>
            <div class="container">
                <h2>Endereço:</h2>
                <div class="form-group">
                    <label for="faixaPeso">Bairro:</label>
                    <input type="text" class="form-control" id="faixaPeso" value="<?php //echo @(isset($racaObject)? $racaObject->getFaixaPeso():'')   ?>" name="faixaPeso">
                </div>
                <div class="form-group">
                    <label for="faixaPeso">Rua:</label>
                    <input type="text" class="form-control" id="faixaPeso" value="<?php //echo @(isset($racaObject)? $racaObject->getFaixaPeso():'')   ?>" name="faixaPeso">
                </div>
                <div class="form-group">
                    <label for="faixaPeso">Complemento:</label>
                    <input type="text" class="form-control" id="faixaPeso" value="<?php //echo @(isset($racaObject)? $racaObject->getFaixaPeso():'')   ?>" name="faixaPeso">
                </div>
            </div>

            <br> 
          
                <div class="d-grid">

                    <button type="submit"class="btn btn-success">Enviar</button>

                </div>                           </div>

        </form>
    </body>

</html>
